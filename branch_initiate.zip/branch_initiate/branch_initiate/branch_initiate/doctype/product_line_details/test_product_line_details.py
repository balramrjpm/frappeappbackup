# Copyright (c) 2024, Balram Singh and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestProductLineDetails(FrappeTestCase):
	pass
